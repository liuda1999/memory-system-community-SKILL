#!/usr/bin/env python3
"""
Scan MEMORY.md to find matching experience files for the current task.

Usage:
    startup_scan.py --workspace <path> --task "<current task description>"

Examples:
    startup_scan.py --workspace /path/to/workspace \\
        --task "用户要求我帮他配置数据库连接"

The script reads MEMORY.md, parses all indexed entries (trigger keywords + trigger conditions),
scores each entry against the task text using substring matching,
and prints paths to the top-matching experience files.
"""

import argparse
import re
import sys
from pathlib import Path


def find_memory_md(workspace: Path) -> Path | None:
    candidates = [
        workspace / "MEMORY.md",
        workspace / "memory.md",
        workspace / "docs" / "MEMORY.md",
    ]
    for c in candidates:
        if c.exists():
            return c
    return None


def parse_memory_index(memory_text: str) -> list[dict]:
    """Parse MEMORY.md entries. Returns list of dicts with filename, keywords, conditions."""
    entries = []
    lines = memory_text.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        # Look for "- filename.md" pattern
        m = re.match(r"^\s*-\s+([\w\-_.]+\.md)\s*$", line)
        if m:
            entry = {"filename": m.group(1), "keywords": [], "conditions": []}
            i += 1
            # Look for following keyword/condition lines
            while i < len(lines):
                next_line = lines[i].strip()
                if next_line.startswith("- ") and next_line.endswith(".md") and ".md" in next_line:
                    i -= 1  # back up, it's a new entry start
                    break
                kw_match = re.match(r"^.*触发关键词[：:](.*)$", next_line)
                if kw_match:
                    raw = kw_match.group(1)
                    entry["keywords"] = re.findall(r'[\u201c"](.*?)[\u201d"]', raw)
                    i += 1
                    continue
                cond_match = re.match(r"^.*触发条件[：:](.*)$", next_line)
                if cond_match:
                    raw = cond_match.group(1)
                    entry["conditions"] = re.findall(r'[\u201c"](.*?)[\u201d"]', raw)
                    i += 1
                    continue
                if next_line == "" or next_line.startswith("#"):
                    i += 1
                    break
                i += 1
            entries.append(entry)
        else:
            i += 1
    return entries


def _word_parts(text: str) -> set[str]:
    """Split a keyword into individual meaningful parts.
    'CI优化' → {'CI', '优化'}; 'merge-conflict' → {'merge', 'conflict'}"""
    parts = set()
    for token in re.split(r'[\s_\-]+', text):
        # Split English/CJK boundaries
        for seg in re.findall(r'[a-zA-Z0-9]+|[\u4e00-\u9fff]+', token):
            if seg:
                parts.add(seg.lower())
    return parts


def score_entry(entry: dict, task_text: str) -> float:
    """Score relevance using multi-level substring matching.

    Level 1: Exact keyword/condition substring in task text
    Level 2: Partial match — individual word parts of a keyword found in task

    Handles cases like: stored keywords "CI优化", task says "CI太慢了需要优化"
    → "CI优化" doesn't match as substring, but "CI" + "优化" both appear.
    """
    all_triggers = set(entry["keywords"]) | set(entry["conditions"])
    if not all_triggers:
        return 0.0

    task_lower = task_text.lower()
    score = 0.0

    for t in all_triggers:
        t_lower = t.lower()
        # Level 1: exact substring
        if t_lower in task_lower:
            score += 1.0
            continue
        # Level 2: partial match — all word parts found in task
        parts = _word_parts(t)
        if parts:
            matched = sum(1 for p in parts if p in task_lower)
            if matched == len(parts) and parts:
                score += 0.5  # partial credit

    return score / len(all_triggers)


def main():
    parser = argparse.ArgumentParser(description="Scan MEMORY.md for matching experiences")
    parser.add_argument("--workspace", required=True, help="Path to workspace directory")
    parser.add_argument("--task", required=True, help="Current task description to match against")
    parser.add_argument("--min-score", type=float, default=0.05,
                        help="Minimum match score (0.0-1.0, default 0.05)")
    parser.add_argument("--max-results", type=int, default=5,
                        help="Maximum results to return (default 5)")
    args = parser.parse_args()

    workspace = Path(args.workspace).resolve()
    if not workspace.is_dir():
        print(f"[ERROR] Workspace not found: {workspace}", file=sys.stderr)
        sys.exit(1)

    memory_path = find_memory_md(workspace)
    if not memory_path:
        print("[INFO] No MEMORY.md found in workspace.")
        sys.exit(0)

    memory_text = memory_path.read_text(encoding="utf-8")
    entries = parse_memory_index(memory_text)

    if not entries:
        print("[INFO] No experience entries found in MEMORY.md.")
        sys.exit(0)

    scored = [(score_entry(e, args.task), e) for e in entries]
    scored.sort(key=lambda x: x[0], reverse=True)

    matching = [(s, e) for s, e in scored if s >= args.min_score]
    top_matches = matching[:args.max_results]

    if not top_matches:
        print(f"[INFO] No matching experiences (threshold: {args.min_score}).")
        sys.exit(0)

    print(f"Found {len(top_matches)} matching experience(s):\n")
    for score, entry in top_matches:
        exp_file = workspace / "experience" / entry["filename"]
        if exp_file.exists():
            status = "✓ exists"
        else:
            status = "⚠ missing"
        print(f"  [{score:.0%}] {entry['filename']}  ({status})")
        print(f"         Keywords: {', '.join(entry['keywords'][:6])}")
        print(f"         Conditions: {', '.join(entry['conditions'][:4])}")
        print(f"         Path: {exp_file}")
        print()

    return 0


if __name__ == "__main__":
    sys.exit(main())
