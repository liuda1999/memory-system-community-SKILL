#!/usr/bin/env python3
"""
Merge semantically similar experience files and clean up MEMORY.md.

Usage:
    merge_experiences.py --workspace <path> [--dry-run]
    merge_experiences.py --workspace <path> --force-merge <file1,file2>

Modes:
    --dry-run      Scan and report without making changes
    --force-merge  Comma-separated filenames to merge manually

Automatic handling (no --dry-run):
  ① Orphan index entries (file missing) → auto-remove from MEMORY.md
  ② Unindexed files (exist but not in MEMORY.md) → auto-parse header and add index
  ③ High-similarity pairs (keywords/conditions >80% + content >80%) → auto-merge,
     newer file (by Date) keeps identity, older content appended silently
  ④ Broken files (missing fields) → report specific missing fields, no auto action
"""

import argparse
import re
import sys
from pathlib import Path


VALID_EVENT_TYPES = {"decision", "lesson", "success", "failure", "idea", "config", "note"}
AUTO_MERGE_KEYWORD_THRESHOLD = 0.8
AUTO_MERGE_CONTENT_THRESHOLD = 0.8


def find_memory_md(workspace: Path) -> Path | None:
    candidates = [
        workspace / "MEMORY.md",
        workspace / "memory.md",
        workspace / "docs" / "MEMORY.md",
    ]
    for c in candidates:
        if c.exists():
            return c
    return None


def parse_memory_index(memory_text: str) -> list[dict]:
    """Parse MEMORY.md entries."""
    entries = []
    lines = memory_text.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        m = re.match(r"^\s*-\s+([\w\-_.]+\.md)\s*$", line)
        if m:
            entry = {
                "filename": m.group(1),
                "keywords": [],
                "conditions": [],
                "start_line": i,
                "end_line": i,
            }
            i += 1
            while i < len(lines):
                next_line = lines[i].strip()
                if next_line.startswith("- ") and next_line.endswith(".md") and ".md" in next_line:
                    i -= 1
                    break
                kw_match = re.match(r"^.*触发关键词[：:](.*)$", next_line)
                if kw_match:
                    raw = kw_match.group(1)
                    entry["keywords"] = re.findall(r'[\u201c"](.*?)[\u201d"]', raw)
                    entry["end_line"] = i
                    i += 1
                    continue
                cond_match = re.match(r"^.*触发条件[：:](.*)$", next_line)
                if cond_match:
                    raw = cond_match.group(1)
                    entry["conditions"] = re.findall(r'[\u201c"](.*?)[\u201d"]', raw)
                    entry["end_line"] = i
                    i += 1
                    continue
                if next_line == "" or next_line.startswith("#"):
                    break
                i += 1
            entries.append(entry)
        else:
            i += 1
    return entries


def parse_experience_file(filepath: Path) -> dict | None:
    """Parse an experience file. Returns dict or None if unreadable."""
    try:
        text = filepath.read_text(encoding="utf-8")
    except Exception:
        return None

    result = {"filepath": str(filepath), "filename": filepath.name, "text": text}
    result["missing_fields"] = []

    # Parse header
    for line in text.splitlines():
        if line.startswith("Event Type:"):
            result["event_type"] = line.split(":", 1)[1].strip()
        elif line.startswith("Event Name:"):
            result["event_name"] = line.split(":", 1)[1].strip()
        elif line.startswith("Date:"):
            result["date"] = line.split(":", 1)[1].strip()
        elif line.startswith("Summary:"):
            result["summary"] = line.split(":", 1)[1].strip()

    # Detect missing header fields
    for field in ["Event Type", "Event Name", "Date", "Summary"]:
        field_key = field.lower().replace(" ", "_")
        if field_key not in result or not result.get(field_key):
            result["missing_fields"].append(field)

    # Extract Full Description and Design
    desc_match = re.search(
        r"## Full Description / Complete Resolution Process\n(.+?)(?=\n## |\Z)", text, re.DOTALL
    )
    if desc_match:
        desc_text = desc_match.group(1).strip()
        if desc_text:
            result["description"] = desc_text
        else:
            result["missing_fields"].append("Full Description")
    else:
        result["missing_fields"].append("Full Description")

    design_match = re.search(r"## Design / Solution\n(.+?)(?=\n## |\Z)", text, re.DOTALL)
    if design_match:
        design_text = design_match.group(1).strip()
        if design_text:
            result["design"] = design_text
        else:
            result["missing_fields"].append("Design / Solution")
    else:
        result["missing_fields"].append("Design / Solution")

    return result


def jaccard_similarity(set1: set, set2: set) -> float:
    """Jaccard similarity between two sets."""
    if not set1 or not set2:
        return 0.0
    return len(set1 & set2) / len(set1 | set2)


def keyword_similarity(kw1: list[str], kw2: list[str]) -> float:
    return jaccard_similarity(set(kw1), set(kw2))


def content_similarity(a: dict, b: dict) -> float:
    """Compare two experiences by extracting topic keywords from content.

    Works on semantic level: two files about "web scraping with requests"
    share topic keywords like 爬虫/网页/抓取/数据/请求 even if phrased differently.
    """
    # Extract topic keywords from both full experience entries
    kw_a = set(extract_keywords_from_experience(a))
    kw_b = set(extract_keywords_from_experience(b))

    if not kw_a or not kw_b:
        return 0.0

    # Take top 10 per file (most distinctive keywords)
    kw_a = set(list(kw_a)[:10])
    kw_b = set(list(kw_b)[:10])

    return jaccard_similarity(kw_a, kw_b)


def extract_keywords_from_experience(pf: dict) -> list[str]:
    """Extract keywords from an experience file's content."""
    text = (
        (pf.get("summary", "") or "") + " " +
        (pf.get("description", "") or "") + " " +
        (pf.get("design", "") or "") + " " +
        (pf.get("event_name", "") or "")
    )
    words = []

    # Chinese: extract 2-4 char sub-phrases from CJK sequences
    cjk = re.findall(r"[\u4e00-\u9fff]+", text)
    for chunk in cjk:
        if len(chunk) <= 4:
            words.append(chunk)
        else:
            for i in range(len(chunk)):
                for j in range(2, 5):
                    if i + j <= len(chunk):
                        words.append(chunk[i:i+j])

    # English: words 2+ chars
    en = re.findall(r"\b[a-zA-Z_][a-zA-Z_]{2,}\b", text)
    words.extend(w.lower() for w in en)

    # Filter stop words
    stop = {"the", "and", "for", "this", "that", "with", "from", "what",
            "how", "why", "not", "are", "was", "has", "had", "can", "will",
            "all", "any", "but", "did", "get", "got", "its", "may", "per",
            "see", "set", "two", "use", "way"}
    words = [w for w in words if w.lower() not in stop]

    # Deduplicate while preserving order, limit to 12
    seen = set()
    result = []
    for w in words:
        if w not in seen:
            seen.add(w)
            result.append(w)
    return result[:12]


def auto_merge(newer: dict, older: dict) -> tuple[str, list[str], list[str], str]:
    """Merge newer file into base (newer keeps identity, older appended)."""
    merged_name = newer.get("event_name", "")
    merged_summary = f"{newer.get('summary', '')} / {older.get('summary', '')}"
    merged_date = newer.get("date", "0000-00-00")

    desc_newer = newer.get("description", "")
    desc_older = older.get("description", "")
    combined_desc = f"{desc_newer}\n\n---\n\n{desc_older}" if desc_older else desc_newer

    design_newer = newer.get("design", "")
    design_older = older.get("design", "")
    combined_design = f"{design_newer}\n\n---\n\n{design_older}" if design_older else design_newer

    merged_keywords = list(dict.fromkeys(newer.get("keywords", []) + older.get("keywords", [])))
    merged_conditions = list(dict.fromkeys(newer.get("conditions", []) + older.get("conditions", [])))
    event_type = newer.get("event_type", "note")

    new_filename = f"{event_type}_{merged_name}.md"

    content = f"""Event Type: {event_type}
Event Name: {merged_name}
Date: {merged_date}
Summary: {merged_summary}

## Full Description / Complete Resolution Process
{combined_desc}

## Design / Solution
{combined_design}
"""

    return content.strip() + "\n", merged_keywords, merged_conditions, new_filename


def rebuild_memory_index(memory_lines: list[str], entries_to_remove: list[dict],
                         entries_to_add: list[tuple[str, list[str], list[str]]]) -> str:
    """Rebuild MEMORY.md by removing specified entries and adding new ones."""
    remove_ranges = []
    for entry in entries_to_remove:
        start = entry.get("start_line", 0)
        end = entry.get("end_line", start)
        remove_ranges.append((start, end))
    remove_ranges.sort(key=lambda r: r[0], reverse=True)
    for start, end in remove_ranges:
        del memory_lines[start:end + 1]
    for filename, keywords, conditions in entries_to_add:
        if not any(filename in line for line in memory_lines):
            key_line = "  触发关键词：" + "、".join(f"“{k}”" for k in keywords)
            cond_line = "  触发条件：" + "、".join(f"“{c}”" for c in conditions)
            memory_lines.append(f"\n- {filename}\n{key_line}\n{cond_line}")
    return "\n".join(memory_lines).strip() + "\n"


def main():
    parser = argparse.ArgumentParser(description="Merge similar experiences and cleanup MEMORY.md")
    parser.add_argument("--workspace", required=True, help="Path to workspace directory")
    parser.add_argument("--dry-run", action="store_true", help="Only report, do not modify")
    parser.add_argument("--force-merge", help="Comma-separated filenames to merge manually")
    args = parser.parse_args()

    workspace = Path(args.workspace).resolve()
    if not workspace.is_dir():
        print(f"[ERROR] Workspace not found: {workspace}", file=sys.stderr)
        sys.exit(1)

    exp_dir = workspace / "experience"
    memory_path = find_memory_md(workspace)

    if not memory_path:
        print("[INFO] No MEMORY.md found. Nothing to do.")
        sys.exit(0)

    memory_text = memory_path.read_text(encoding="utf-8")
    memory_lines = memory_text.splitlines()
    index_entries = parse_memory_index(memory_text)

    # ================================================================
    # Phase 1: Orphan entries + Unindexed files + Broken files
    # ================================================================
    print("=" * 60)
    print("Phase 1: Scan orphans, unindexed files, broken files")
    print("=" * 60)

    orphan_entries = []
    unindexed_files = []
    broken_files: list[tuple[str, list[str]]] = []

    # Check each MEMORY.md entry
    for entry in index_entries:
        exp_file = workspace / "experience" / entry["filename"]
        if not exp_file.exists():
            orphan_entries.append(entry)
            print(f"  [ORPHAN] '{entry['filename']}' — file not found, will remove index")

    # Check each file in experience/
    if exp_dir.exists():
        existing_files = {f.name for f in exp_dir.iterdir() if f.suffix == ".md"}
        indexed_files = {e["filename"] for e in index_entries}

        for fname in sorted(existing_files):
            pf = parse_experience_file(exp_dir / fname)
            if pf is None:
                broken_files.append((fname, ["File is unreadable"]))
                print(f"  [BROKEN] '{fname}' — unreadable")

            elif fname not in indexed_files:
                if pf.get("missing_fields"):
                    broken_files.append((fname, pf["missing_fields"]))
                    print(f"  [BROKEN] '{fname}' — missing fields: {', '.join(pf['missing_fields'])}")
                else:
                    unindexed_files.append(pf)
                    print(f"  [UNINDEXED] '{fname}' — will auto-index")
            else:
                if pf.get("missing_fields"):
                    broken_files.append((fname, pf["missing_fields"]))
                    print(f"  [BROKEN] '{fname}' — indexed but missing fields: {', '.join(pf['missing_fields'])}")

    if not orphan_entries and not unindexed_files and not broken_files:
        print("  All clean. ✓")

    # ================================================================
    # Phase 2: Find high-similarity pairs for auto-merge
    # ================================================================
    print()
    print("=" * 60)
    print("Phase 2: Find auto-merge candidates (>80% threshold)")
    print("=" * 60)

    parsed_files = []
    for entry in index_entries:
        exp_file = workspace / "experience" / entry["filename"]
        if not exp_file.exists():
            continue
        pf = parse_experience_file(exp_file)
        if pf is None or pf.get("missing_fields"):
            continue
        pf["filename"] = entry["filename"]
        pf["keywords"] = entry["keywords"]
        pf["conditions"] = entry["conditions"]
        parsed_files.append(pf)

    # Group by event_type and find auto-mergeable pairs
    by_type: dict[str, list[dict]] = {}
    for pf in parsed_files:
        et = pf.get("event_type", "note")
        by_type.setdefault(et, []).append(pf)

    auto_merge_pairs = []
    for etype, group in by_type.items():
        if len(group) < 2:
            continue
        for i in range(len(group)):
            for j in range(i + 1, len(group)):
                a, b = group[i], group[j]

                # Step 1: keyword + condition similarity
                all_triggers_a = set(a.get("keywords", [])) | set(a.get("conditions", []))
                all_triggers_b = set(b.get("keywords", [])) | set(b.get("conditions", []))
                trigger_sim = jaccard_similarity(all_triggers_a, all_triggers_b)

                if trigger_sim < AUTO_MERGE_KEYWORD_THRESHOLD:
                    continue

                # Step 2: content similarity
                cont_sim = content_similarity(a, b)

                if cont_sim < AUTO_MERGE_CONTENT_THRESHOLD:
                    print(f"  [THRESHOLD NOT MET] {a['filename']} ↔ {b['filename']}")
                    print(f"      Triggers: {trigger_sim:.0%}, Content: {cont_sim:.0%} — content < 80%")
                    continue

                # Both thresholds met → auto-merge candidate
                # Determine newer vs older by Date field
                date_a = a.get("date", "0000-00-00")
                date_b = b.get("date", "0000-00-00")
                if date_a >= date_b:
                    newer, older = a, b
                else:
                    newer, older = b, a

                auto_merge_pairs.append({
                    "newer": newer,
                    "older": older,
                    "newer_date": max(date_a, date_b),
                    "older_date": min(date_a, date_b),
                    "trigger_similarity": round(trigger_sim, 2),
                    "content_similarity": round(cont_sim, 2),
                })
                newer_date_str = newer.get("date", "?")
                older_date_str = older.get("date", "?")
                print(f"  ✓ {newer['filename']}  (newer, {newer_date_str})")
                print(f"    ← {older['filename']}  (older, {older_date_str})")
                print(f"    Triggers: {trigger_sim:.0%}, Content: {cont_sim:.0%} — auto-merge will proceed")

    if not auto_merge_pairs and not orphan_entries and not unindexed_files and not broken_files:
        print("  Nothing to do. ✓")

    # ================================================================
    # Phase 3: Execute
    # ================================================================
    if args.dry_run:
        print()
        print("=" * 60)
        print("DRY RUN — no changes made.")
        print("=" * 60)
        sys.exit(0)

    entries_to_remove: list[dict] = []
    entries_to_add: list[tuple[str, list[str], list[str]]] = []

    # --- ① Auto-clean orphan entries ---
    if orphan_entries:
        print()
        print("=" * 60)
        print("Phase 3: ① Auto-cleaning orphan index entries")
        print("=" * 60)
        for entry in orphan_entries:
            print(f"  Removed: {entry['filename']} (file missing)")
            entries_to_remove.append(entry)

    # --- ② Auto-index unindexed files ---
    if unindexed_files:
        print()
        print("=" * 60)
        print("Phase 3: ② Auto-indexing unindexed experience files")
        print("=" * 60)
        for pf in unindexed_files:
            keywords = extract_keywords_from_experience(pf)
            conditions = [f"关于{pf.get('event_name', '')}的事项"]
            entries_to_add.append((pf["filename"], keywords, conditions))
            print(f"  Indexed: {pf['filename']} ({len(keywords)} keywords)")

    # --- ③ Auto-merge high-similarity pairs ---
    if auto_merge_pairs:
        print()
        print("=" * 60)
        print("Phase 3: ③ Auto-merging high-similarity pairs")
        print("=" * 60)
        for pair in auto_merge_pairs:
            newer, older = pair["newer"], pair["older"]
            merged_content, merged_kw, merged_cond, new_fname = auto_merge(newer, older)

            # Mark old entries for removal
            for entry in index_entries:
                if entry["filename"] in [newer["filename"], older["filename"]]:
                    if entry not in entries_to_remove:
                        entries_to_remove.append(entry)

            # Add new entry
            entries_to_add.append((new_fname, merged_kw, merged_cond))

            # Remove old files (delete older first to avoid conflicts)
            for fname in [older["filename"], newer["filename"]]:
                old_file = workspace / "experience" / fname
                if old_file.exists():
                    old_file.unlink()
                    print(f"  Removed: {old_file.name}")

            # Write merged file
            merged_path = workspace / "experience" / new_fname
            merged_path.write_text(merged_content, encoding="utf-8")
            print(f"  Created: {merged_path.name}")
            print(f"    ← Merged '{older['filename']}' (older, {pair['older_date']})")
            print(f"    → Into '{newer['filename']}' (newer, {pair['newer_date']})")

    # --- Apply all MEMORY.md changes ---
    if entries_to_remove or entries_to_add:
        new_memory = rebuild_memory_index(memory_lines, entries_to_remove, entries_to_add)
        memory_path.write_text(new_memory, encoding="utf-8")
        print(f"\n  Updated: {memory_path}")

    # --- ④ Broken files (report only) ---
    if broken_files:
        print()
        print("=" * 60)
        print("Phase 3: ④ Broken files (report only, no auto action)")
        print("=" * 60)
        for fname, missing in broken_files:
            print(f"  ⚠ {fname}")
            for field in missing:
                print(f"       Missing: {field}")

    if not entries_to_remove and not entries_to_add and not auto_merge_pairs and not broken_files and not (orphan_entries or unindexed_files):
        print("\n  Nothing to do. ✓")

    print(f"\n[DONE] Orphans: {len(orphan_entries)} cleaned, "
          f"Unindexed: {len(unindexed_files)} indexed, "
          f"Merges: {len(auto_merge_pairs)} done, "
          f"Broken: {len(broken_files)} reported")
    return 0


if __name__ == "__main__":
    sys.exit(main())
