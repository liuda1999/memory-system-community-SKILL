#!/usr/bin/env python3
"""
Quick-turn logger: append the current conversation turn to today's daily log.
Call this at the END of each assistant response, BEFORE any other actions.

Usage:
    python3 append_turn.py <workspace> "<user message>" "<assistant reply>"

Exits silently on success, prints error on failure.
"""

import sys
from datetime import datetime
from pathlib import Path


def main():
    if len(sys.argv) != 4:
        return  # silent no-op if called wrong

    workspace = Path(sys.argv[1]).resolve()
    user_msg = sys.argv[2]
    reply = sys.argv[3]

    if not workspace.is_dir():
        return

    memory_dir = workspace / "memory"
    memory_dir.mkdir(parents=True, exist_ok=True)

    today = datetime.now()
    date_str = today.strftime("%Y-%m-%d")
    time_str = today.strftime("%H:%M")
    log_file = memory_dir / f"{date_str}.md"

    # Create with header if new file
    if not log_file.exists():
        log_file.write_text(f"# Daily log for {date_str}\n\n", encoding="utf-8")

    # Append turn block
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(f"## [{time_str}] User\n")
        f.write(f"{user_msg}\n\n")
        f.write(f"## [{time_str}] Assistant\n")
        f.write(f"{reply}\n\n")


if __name__ == "__main__":
    main()
