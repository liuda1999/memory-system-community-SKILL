#!/usr/bin/env python3
"""
Append a conversation turn to today's raw daily log.

Usage:
    daily_log.py --workspace <path> --user-msg "<user message>" --reply "<assistant reply>"

Examples:
    daily_log.py --workspace /path/to/workspace \\
        --user-msg "帮我查一下明天的天气" \\
        --reply "明天上海晴转多云，25-30°C"

The script creates memory/YYYY-MM-DD.md in the workspace if it does not exist,
then appends the turn with timestamps.
"""

import argparse
import sys
from datetime import datetime
from pathlib import Path


def ensure_dir(path: Path) -> None:
    """Create directory if it does not exist."""
    path.mkdir(parents=True, exist_ok=True)


def main():
    parser = argparse.ArgumentParser(description="Append a conversation turn to today's daily log")
    parser.add_argument("--workspace", required=True, help="Path to workspace directory")
    parser.add_argument("--user-msg", required=True, help="User message content")
    parser.add_argument("--reply", required=True, help="Assistant reply content")
    args = parser.parse_args()

    workspace = Path(args.workspace).resolve()
    if not workspace.is_dir():
        print(f"[ERROR] Workspace not found: {workspace}", file=sys.stderr)
        sys.exit(1)

    memory_dir = workspace / "memory"
    ensure_dir(memory_dir)

    today = datetime.now()
    date_str = today.strftime("%Y-%m-%d")
    time_str = today.strftime("%H:%M")
    log_file = memory_dir / f"{date_str}.md"

    # Create with header if new file
    if not log_file.exists():
        log_file.write_text(f"# Daily log for {date_str}\n\n", encoding="utf-8")

    # Append turn block
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(f"## [{time_str}] User\n")
        f.write(f"{args.user_msg}\n\n")
        f.write(f"## [{time_str}] Assistant\n")
        f.write(f"{args.reply}\n\n")

    print(f"[OK] Appended turn to {log_file}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
